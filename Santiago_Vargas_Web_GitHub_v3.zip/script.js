const menu=document.querySelector('.menu');
const nav=document.querySelector('#navegacion');
menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));nav.classList.toggle('open',open);});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&nav.classList.contains('open')){menu.setAttribute('aria-expanded','false');nav.classList.remove('open');menu.focus();}});
const playerButton=document.querySelector('.load-player');
if(playerButton)playerButton.addEventListener('click',()=>{const frame=document.createElement('iframe');frame.src='https://open.spotify.com/embed/show/2LAdhaTCQYo4unEwVoZ6aO';frame.title='Ciencia Viral en Spotify';frame.allow='encrypted-media; fullscreen; picture-in-picture';frame.loading='lazy';playerButton.replaceWith(frame);});
