# Santiago Vargas Domínguez — sitio personal

Primera versión en español, inspirada en la organización de contenidos del sitio de Brian Greene y con diseño propio. Sitio estático sin dependencias: HTML, CSS y JavaScript. Funciona en GitHub Pages y localmente abriendo `index.html`.

## Publicar en GitHub Pages

1. Descomprime el paquete.
2. Crea un repositorio en GitHub o utiliza el destinado a tu página.
3. Sube el contenido de esta carpeta: `index.html` debe quedar en la raíz del repositorio, junto a los demás HTML, `styles.css`, `script.js` y `assets/`.
4. En el repositorio, abre **Settings → Pages**.
5. En **Build and deployment → Source**, selecciona **Deploy from a branch**.
6. Selecciona **main**, carpeta **/(root)** y pulsa **Save**.
7. GitHub mostrará la dirección de la página al finalizar la publicación. Revisa el despliegue en la pestaña Actions si aparece un error.

Fuente: [Documentación oficial de GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## Actualizar contenido

Edita el HTML de la sección correspondiente. Los cambios se publican al guardarlos en la rama elegida.

| Archivo | Contenido |
| --- | --- |
| index.html | Portada y accesos destacados |
| trayectoria.html | Biografía, formación, experiencia y reconocimientos |
| investigacion.html | Líneas, proyectos y publicaciones seleccionadas |
| docencia.html | Cursos y tesis |
| comunidad.html | Jurados, membresías y gestión |
| divulgacion.html | Libros, artículos y divulgación |
| styles.css | Tipografía, colores y presentación adaptable |
| script.js | Menú móvil |
| assets/ | Fotografías optimizadas y favicon |

Los cursos están agrupados en bloques `<details>`, que el visitante puede desplegar. Para añadir un nuevo curso, duplica uno de esos bloques. Las tesis, publicaciones y libros usan `<article class="editorial-row">`: duplica un bloque y sustituye sus textos.

La página de trayectoria incluye un botón para imprimirla o guardarla como PDF mediante el navegador. No se distribuye el CV original, que contiene teléfono personal y datos de contacto de terceros.

## Contenido y revisión editorial

Fuentes: CV proporcionado (actualización indicada en agosto de 2026), hoja de estadísticas y texto biográfico adjunto. Los enlaces de artículos proceden de esos materiales; no se ha verificado su disponibilidad individual.

- Se incorporaron 113 registros de curso-periodo, agrupados por el nombre registrado; algunas variantes ortográficas pueden corresponder a una misma asignatura.
- Se incorporaron 30 trabajos de tesis con autor y título disponibles. El registro adicional de Lady Julieth Useche Galindo carece de título y programa, por lo que no aparece en la web.
- No se publican estados de finalización ni fechas inferidas de tesis: el registro incluye casos con sustentación y estado «En curso» simultáneos.
- Conviene confirmar la escritura de los nombres de estudiantes en el Excel, especialmente Germain Nicolás Morales, Johan Samir y otros nombres abreviados. Se corrigieron erratas inequívocas de María Paula Silva Arévalo y Willinton Caicedo a partir de la información suministrada.
- La bibliografía es una selección. El propio CV advierte que su exportación de Google Scholar contiene posibles homónimos y duplicados. No se reproducen automáticamente sus métricas ni toda esa lista.
- La sección de jurados describe instituciones y tipos de actividad. No publica nombres ni títulos de manuscritos o propuestas sometidos a evaluación.
- La información de membresías y cargos se basa en el material recibido; revisar su vigencia antes de la publicación definitiva.
- El catálogo actual incluye las nueve portadas, obtenidas de las nuevas imágenes del autor y de fuentes editoriales identificadas al final de estas instrucciones.
- El sitio está en español. No se ha creado todavía una versión en inglés.

## Fotografías

Se usaron las fotografías aportadas por el autor, convertidas a WebP para reducir el peso. Los derechos de las imágenes y textos corresponden a sus titulares. No se copió código, imágenes ni identidad gráfica de Brian Greene.

## Comprobaciones de esta versión

Se comprobó la sintaxis de JavaScript y la existencia de todos los destinos y anclas internos de las seis páginas, además de los archivos de imagen. La revisión visual automatizada y las pruebas de interacción en navegador no pudieron completarse porque no había un navegador instalado y su descarga no respondió. Conviene abrir `index.html` en un navegador de escritorio y en un teléfono antes de publicar.

## Actualización de pódcast, radio y publicaciones

- Perfil suministrado por el autor: https://scholar.google.com/citations?hl=en&user=9DDaTaAAAAAJ&view_op=list_works&sortby=pubdate
- Google Scholar devolvió una limitación de acceso al intentar leer el listado. Se añadió el enlace al perfil ordenado por fecha; no se importaron enlaces individuales ni se afirma que el sitio se sincronice automáticamente.
- Ciencia Viral: https://open.spotify.com/show/2LAdhaTCQYo4unEwVoZ6aO . Incluye enlace directo y reproductor opcional, que requiere conexión a Spotify. Si el reproductor no carga, el enlace directo permanece disponible.
- Conocimiento y Sociedad, conducido por Santiago Vargas y Zulma Dueñas: https://radio.unal.edu.co/categorias/programa/conocimiento-y-sociedad . Descripción basada en la página oficial y la información del autor.
- Se incorporaron fotografías del autor en docencia y trayectoria y una galaxia ilustrada en la portada y el espacio de audio. La ilustración está identificada como generada con IA; no representa una observación científica concreta. Las fotografías originales del autor se conservan; la tercera versión añade una ilustración identificada como tal para representar la mentoría.

Imagen nueva: `assets/cosmos.webp`, generada con la herramienta integrada de imágenes. Prompt: «Panoramic artistic spiral galaxy, intricate dust lanes, warm pearl core on the right, restrained indigo nebula wisps and stars against near-black space, dark left half, natural astronomical aesthetic, no text, no labels, no watermark; artistic illustration, not a scientific observation».


## Cambios de la tercera versión

Se incorporó la portada oficial de Ciencia Viral desde su página de Spreaker, se precisaron las tres descripciones editoriales y se añadió la fotografía de La Calera (2017). Objetos Astrofísicos fue retirado de los cursos. Se añadieron ocho imágenes de cubiertas extraídas por recorte de la composición facilitada por el autor, sin reconstruir letras ni alterar los diseños; su resolución está limitada por el original. La cubierta de Julio Garavito Armero procede del catálogo de ferias de la UNAL: https://catalogoferias.unal.edu.co/julio-garavito-armero-7qgsg.html .

La nueva ilustración de mentoría (`assets/mentoria.webp`) se generó con la herramienta integrada a partir del retrato del autor. Prompt: profesor Santiago Vargas con tres estudiantes universitarios adultos en una sala de estudio de observatorio, conversando sobre astronomía, luz natural, estilo editorial ilustrado y rasgos faciales basados en el retrato; sin texto ni logotipos. Se identifica como ilustración, no como fotografía de una sesión real.

Fuente de la imagen oficial de Ciencia Viral: https://www.spreaker.com/podcast/ciencia-viral--4779937 .


### Enlaces a tesis contrastados con registros académicos

Los enlaces institucionales se recuperaron de metadatos de la UNAL recolectados por Redcol (Minciencias). La consulta directa del repositorio está bloqueada para la herramienta de navegación. Se cotejaron autores y títulos; no se considera que una coincidencia de título por sí sola identifique una tesis.

- Johana Katerine Morales Chaparro: https://repositorio.unal.edu.co/handle/unal/56417 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_26a4eb428dcc25c275c61174d2667f58
- Julián Alberto Pico Arévalo: https://repositorio.unal.edu.co/handle/unal/58636 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_4ce0e776e4c55921feac6b3d953d7161
- José Iván Campos Rozo: https://repositorio.unal.edu.co/handle/unal/59001 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_9a442c93f9748fa7c9ada8c686860a6f
- Álvaro Baquero Soler: https://repositorio.unal.edu.co/handle/unal/69771 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_7f2c1b3462c1e6c477038d012549898e
- Yeimy Gerardine Berrios Saavedra: https://repositorio.unal.edu.co/handle/unal/79614 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_77966d10b33c815db3750e76463b4fc8
- John Fredy Puentes Torres: https://repositorio.unal.edu.co/handle/unal/80732 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_964102dfba3f53e5dcddb477cde96ae2
- Erika Paola Puentes León: https://repositorio.unal.edu.co/handle/unal/86064 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_a114fc7c1b12f25197c039d347b14c49
- Érika Yiseth Hernández Vásquez: https://repositorio.unal.edu.co/handle/unal/83731 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_ffbd743f7653a27c87e1e6419e0e19ce
- Frank Jair Bautista Sánchez: https://repositorio.unal.edu.co/handle/unal/80194 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_0919a88d963080d1ac836aac806ffbb4
- Germain Nicolás Morales Suarez: https://repositorio.unal.edu.co/handle/unal/85995 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_13cb07e96720a9742bc266c4da47b6a3
- Johan Nicolás Molina Córdoba: https://repositorio.unal.edu.co/handle/unal/85032 — registro de contraste: https://redcol.minciencias.gov.co/Record/UNACIONAL2_2e38a9bae1434df2dc229cc9e57e83fc

El registro de Marte encontrado corresponde a Johan Nicolás Molina Córdoba, por lo que no se enlazó a la entrada de María Paula Silva Arévalo, aunque el Excel contiene el mismo título para ambos. Las entradas sin enlace no tienen una coincidencia institucional verificada.


Actualización de fuentes de imágenes: Mujer es Ciencia se reemplazó por una cubierta de mayor resolución obtenida en https://mujeresconciencia.com/2021/10/02/mujer-es-ciencia/ . Las otras siete cubiertas de la composición adjunta conservan el recorte del original.

Se publican 11 enlaces a tesis contrastados por autor y título. Se buscaron también las demás entradas, pero no se añadieron coincidencias dudosas, artículos relacionados o trabajos de autores diferentes. Objetos Astrofísicos ya no forma parte del registro visible de cursos; las cifras de 113 registros mencionadas antes corresponden a la importación inicial.
